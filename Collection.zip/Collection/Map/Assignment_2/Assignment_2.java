import java.util.*;

public class Assignment_2
{
    public static void main(String args[]) {
        final int SIZE = 2;
        Scanner in = new Scanner(System.in);
        String names[] = new String[SIZE];
        long telNos[] = new long[SIZE];
        System.out.println("Enter " + SIZE + " names and telephone numbers");
        for (int i = 0;  i < SIZE; i++) {
            System.out.print("Enter Name: ");
            names[i] = in.nextLine();
            System.out.print("Enter telephone number: ");
            telNos[i] = in.nextLong();
            in.nextLine();
        }
        
        for (int i = 0; i < SIZE - 1; i++) {
            int min = i;
            for (int j = i + 1; j < SIZE; j++) {
                if (names[j].compareToIgnoreCase(names[min]) < 0) {
                    min = j;
                }
            }
            String temp = names[min];
            names[min] = names[i];
            names[i] = temp;
            
            long t = telNos[min];
            telNos[min] = telNos[i];
            telNos[i] = t;
        }
        
        System.out.println("Name\tTelephone Number");
        for (int i = 0; i < SIZE; i++) {
            System.out.println(names[i] + "\t" + telNos[i]);
        }
    }
}