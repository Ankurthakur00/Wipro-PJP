import java.util.*;
public class Assignment_3 {
	public static void main(String[] args) {
		//Create array list object       
	      List<Integer> Enum = new ArrayList<Integer>();		      
            Enum.add(1100);
            Enum.add(2100);
            Enum.add(5100);
            //Create Enumeration
            Enumeration<Integer> en = Collections.enumeration(Enum);
            System.out.println("The Enumeration List are: ");
            while(en.hasMoreElements()){
                 System.out.println(en.nextElement());
            }	     
	}	  
}
