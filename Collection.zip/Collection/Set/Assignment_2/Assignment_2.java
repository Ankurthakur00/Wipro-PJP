import java.util.Iterator;
import java.util.TreeSet;

public class Assignment_2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> set = new TreeSet<>();
		set.add("anil");
		set.add("John");
		set.add("Arjun");
        	set.add("bhupesh");
        
        	System.out.println("Original tree set:" + set);  
        	Iterator itr1 = set.descendingIterator();
        	System.out.println("Elements in Reverse Order:");
        	while (itr1.hasNext()) {
       			System.out.println(itr1.next());
        	}
		
		Iterator<String> itr2 = set.iterator();
		String query = "adil";
		boolean result = false;
		
		while (itr2.hasNext()) {
			if (itr2.next().equals(query)) {
				result = true;
				break;
			}
		}
		
		if (result) System.out.println(query + " exists");
		else System.out.println(query + " doesn't exist");
	}

}
