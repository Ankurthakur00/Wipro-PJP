/*Initialize two character variables in a program and display the characters in alphabetical order.

Example1) if the first character is 's' and second character is 'e' then the output should be  e,s

Example2) if the first character is 'a' and second character is 'e', then the output should be a,e */

public class Assignment_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char variable1 = 's';
		char variable2 = 'e';
		
		if (variable1 > variable2)
            System.out.println(variable2+" , "+variable1);
        else
            System.out.println(variable1+" , "+variable2);
	}

}
