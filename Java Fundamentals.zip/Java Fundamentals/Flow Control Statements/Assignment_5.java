/*Initialize a character variable in a program and 

print 'Alphabhet' if the initialized value is an alphabhet, 

print 'Digit' if the initialized value is a number, and 

print 'Special Character', if the initialized value is anything else. */
import java.util.Scanner;
public class Assignment_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		char variable = '1';
		
		if((variable >= 65 && variable <= 90) || (variable >= 97 && variable <= 122) ) {
			System.out.println("Alphabet");
		}
		else if(variable >= 48 && variable <= 57) {
			System.out.println("Number");
		}
		else {
			System.out.println("Special Character");
		}
	}

}
