/*Write a program to reverse a given number and print

Example1)
I/P: 1234
O/P:4321

Example2)
I/P:1004
O/P:4001
*/

import java.util.*;

public class Assignment_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number :");
		int num = sc.nextInt();
		int dig, rev = 0;
		
		while(num > 0) {
			dig = num % 10;
			rev = (rev * 10) + dig;
			num = num / 10;
		}
		System.out.println(rev);
	}

}
