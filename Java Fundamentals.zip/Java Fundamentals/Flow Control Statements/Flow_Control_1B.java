import java.util.*;
public class Flow_Control_1B {
	public static void main(String[] args) { 
    Scanner sc = new Scanner(System.in);
    
    System.out.print("Enter the 1st Number: ");
    int m = sc.nextInt();
    
    System.out.print("Enter the 2nd Number: ");
    int n = sc.nextInt();
    
    if(m%10==n%10) {
    	System.out.println("true");
    }
    else {
    	System.out.println("false");
    }
	}
    
}
