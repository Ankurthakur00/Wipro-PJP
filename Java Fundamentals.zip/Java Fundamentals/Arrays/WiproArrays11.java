public class WiproArrays11 {
    public static void main(String[] args) {
        int[] ar= {1,4,2,4};
        int flag=1;
        for (int i :ar) {
            System.out.print(i+ " ");
            if(i!=1 && i!=4)
                flag=0;
        }
        if(flag==1)
            System.out.println("\ntrue");
        else
            System.out.println("\nfalse");
    }
}
