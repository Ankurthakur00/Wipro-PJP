public class WiproArrays9 {
    public static void main(String[] args) {
        int[] ar= {1,10,10,2}, new_ar= new int[ar.length];
        int c=0;
        for (int i :ar) {
            System.out.print(i+ " ");
        }
        for (int i = 0; i < ar.length; i++) {
            if (ar[i] == 10)
                continue;
            new_ar[c] = ar[i];
            c++;
        }
        System.out.println();
        for (int i :new_ar) {
            System.out.print(i+ " ");
        }
    }
}
