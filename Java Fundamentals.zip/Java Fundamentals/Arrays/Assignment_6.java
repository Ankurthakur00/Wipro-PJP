//Write a program to initialize an array and print them in a sorted order.

import java.util.*;

public class Assignment_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {19, 14, 20, 18, 2};
		
		Arrays.sort(arr);												//sort inbuilt function
		
		/*for(int i = 0; i < arr.length-1; i++) {						//sort logic
			for(int j = 0; j < arr.length-1; j++) {
				if(arr[j] > arr[j+1]) {
					int a = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = a;
				}
			}
		}
		*/
		
		System.out.print("Sorted Array : ");
		for(int element : arr) {
			System.out.print(element + " ");
		}
	}

}
