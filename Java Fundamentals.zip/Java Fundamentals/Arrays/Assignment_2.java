//Write a program to initialize an integer array and find the maximum and minimum value of the array.

import java.util.Arrays;

public class Assignment_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {19, 14, 20, 18, 2};
		
		System.out.println("Array: "+Arrays.toString(arr));								
		
		int max = arr[0];																	
		for(int i = 1; i < arr.length; i++) {
			if(arr[i] > max)
				max = arr[i];
		}
		System.out.println("The maximum value of Array is: "+max);
		
		int min = arr[0];																	
		for(int i = 1; i < arr.length; i++) {
			if(arr[i] < min)
				min = arr[i];
		}
		System.out.println("The minimum value of Array is: "+min);
	}

}
