public class WiproArrays12 {
    public static void main(String[] args) {
        int[] a= {1,2,3},
               b= {4,5,6},
                c= new int[2];
        c[0]= a[(int)(Math.ceil(a.length/2))];
        c[1]= b[(int)(Math.ceil(b.length/2))];
        for (int i = 0; i < 3; i++) {
            System.out.print(a[i]+ " ");
        }
        System.out.println();
        for (int i = 0; i < 3; i++) {
            System.out.print(b[i]+ " ");
        }
        System.out.print("\n"+c[0]+ " "+ c[1]);
    }
}
