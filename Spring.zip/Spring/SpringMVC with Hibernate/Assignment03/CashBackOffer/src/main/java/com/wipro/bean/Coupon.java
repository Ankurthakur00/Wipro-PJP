package com.wipro.bean;

public class Coupon {

	private String couponcode;
	private int offerpercentage;

	public String getCouponcode() {
		return couponcode;
	}

	public void setCouponcode(String couponcode) {
		this.couponcode = couponcode;
	}

	public int getOfferpercentage() {
		return offerpercentage;
	}

	public void setOfferpercentage(int offerpercentage) {
		this.offerpercentage = offerpercentage;
	}
}
