package music.string;

import music.Playable;

public class Veena implements Playable {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Playing Veena");
	}

}
