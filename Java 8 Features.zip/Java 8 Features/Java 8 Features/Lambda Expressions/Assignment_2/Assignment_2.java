/*Create an ArrayList al and add 10 different words. 
Write a code to print all the Strings in reverse order, using lambda expression. */


import java.util.ArrayList;

public class Assignment_2 {

	public static void main(String[] args) {
		ArrayList<StringBuffer> al = new ArrayList<StringBuffer>();
String[] arr = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday","One","Two","Three"};
		
		for (String letter : arr) {
			StringBuffer sb = new StringBuffer(letter);
			al.add(sb);
		}
al.forEach(letter -> System.out.print(letter.reverse() + " "));
	}

}
