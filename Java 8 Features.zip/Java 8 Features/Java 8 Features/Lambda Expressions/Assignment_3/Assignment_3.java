/*Create an ArrayList al and add 10 different words.
Write a code to print all the Strings whose length is odd, using lambda expression.  */


import java.util.ArrayList;
import java.util.Arrays;

public class Assignment_3 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>
		(Arrays.asList("One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"));
		
		al.forEach(letter -> System.out.print((letter.length() % 2 != 0) ? letter + " " : ""));
	}

}
